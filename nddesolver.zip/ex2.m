
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Example 2

% Solves the NDDE 
% y'(t)=-2y(t)+y(t-2)+0.5y'(t-2), on t=[0,8]
% with history function sin(pi t)
% using the analytical solution, nddesolver, and ddensd and graphs the
% solution

step=0.01;
t=0:step:8;
delay=2;
interval=[0 8];

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ANALYTICAL SOLUTION

y0=zeros(1,length(t));

for k=1:length(t)
    if t(k)<=2
        y0(k)=sin(pi*t(k))/2;
    elseif t(k)>2&&t(k)<=4
        y0(k)=sin(pi*t(k))/4;
    elseif t(k)>4&&t(k)<=6
        y0(k)=sin(pi*t(k))/8;
    else
        y0(k)=sin(pi*t(k))/16;
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NDDE SOLVER

dydt=[-2 1 0.5];
N=10;
preshape=@(t) sin(pi*t);
soln=nddesolver(dydt,delay,preshape,interval,N,[]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % DDENSD SOLVER
% 
% sol = ddensd(@ddex1de,delay,delay,@ddehist,interval);
% y1=deval(t,sol);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Graphing

figure
plot(t,y0,'k','LineWidth',1.5);
hold
% plot(t,y1,'b--','LineWidth',1.5)
plot(soln.x,soln.y,'r*','LineWidth',1.5)
legend('Y_T','Y_D','Location','NorthEast')
% legend('Y_T','Y_D','Y_N','Location','NorthEast')
title('Example 2')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Error computation
% % make sure that the vectors to compare are of the same size
% err=zeros(length(t),1);
% err1=zeros(length(t),1);
% for k=1:length(t)
%     err(k)=abs(soln.y(k)-y0(k));
%     err1(k)=abs(y1(k)-y0(k));
% end
% 
% E=norm(soln.y-y0')^2/norm(y0')^2;
% E1=norm(y1-y0)^2/norm(y0)^2;
% 
% % Error plot
% figure
% plot(t,err,'LineWidth',1.5)
% hold
% plot(t,err1,'LineWidth',1.5)
% title('Example 2')

%--------------------------------------------------------------------------
function dydt = ddex1de(t,y,Z,ZP)
dydt=-2*y+Z+0.5*ZP;
end
%-------------------------------------------------------------------------
function s=ddehist(t)
s=sin(pi*t);
end
%-------------------------------------------------------------------------