function zetaN=lambda(dydt,delay,n)
% -------------------------------ABOUT THE FUNCTION------------------------
% Computes the values of lambda using the formula
% lambda=(1/delay)W_r(a)-dydt(1)
%
% Note that the number of solutions vary depending on the number of real 
% roots of the r-Lambert W function W_r(a)
%-----------------------------------INPUT----------------------------------
%  1. dydt is a vector containing the coefficients of X,Z,and ZP
%	where  X is a function of t
%       Z is the function of t with constant delay
%       ZP is the derivative function of t with constant delay,
%     from the given equation to be solved, 
%     i.e. given FUN=(a1)X+(a2)Z+(a3)ZP, then dydt=[a1 a2 a3]
%  2. delay is the constant delay in the NDDE
%  3. n is the number of complex roots of W_r(a) with positive imaginary part
%-----------------------------------OUTPUT---------------------------------
%  1. zetaN is a matrix with elements of the form (1/delay)W_r(a)-dydt(1)
%--------------------------------------------------------------------------

[a,r]=RA_solver(dydt,delay);
N=n(length(n));
w=rlambertw(n,a,r)';
if imag(w(3))==0
    zeta=zeros(length(n),1);
    for k=1:N+2
        zeta(k)=(1/delay)*w(k)+dydt(1);
    end
    zetaN=[zeta(1:N+2); conj(zeta(4:N+2))];
    return
elseif imag(w(2))==0
    zeta=zeros(length(n)+1,1);
    for k=1:N+2
        zeta(k)=(1/delay)*w(k)+dydt(1);
    end
    zetaN=[zeta(1:N+2); conj(zeta(3:N+2))];
    return
elseif imag(w(1))==0
    zeta=zeros(length(n),1);
    for k=1:N+1
        zeta(k)=(1/delay)*w(k)+dydt(1);
    end
    zetaN=[zeta(1:N+1); conj(zeta(2:N+1))];
    return
else
    zeta=zeros(length(n),1);
    for k=1:N+1
        zeta(k)=(1/delay)*w(k)+dydt(1);
    end
    zetaN=[zeta(1:N+1); conj(zeta(1:N+1))];
    return
end
