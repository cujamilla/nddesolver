function sol=nddesolver(dydt,delay,preshape,interval,N,s)
% ---------------------------ABOUT THE FUNCTION----------------------------
% Computes the solution of a linear first-order NDDE with constant delay,
% constant coefficients using the r-Lambert W function.
%
% Solution is of the form
%             y(t)=sum_i C(i)*exp(lambda(i)*t), i=1,...,n
% for some coefficients C and lambda.
%-----------------------------------INPUT----------------------------------
%  1. dydt is a vector containing the coefficients of X,Z,and ZP
%	where  X is a function of t
%       Z is the function of t with constant delay
%       ZP is the derivative function of t with constant delay,
%     from the given equation to be solved, 
%     i.e. given FUN=(a1)X+(a2)Z+(a3)ZP, then dydt=[a1 a2 a3]
%  2. delay is the constant delay in the NDDE
%  3. preshape is the history function on the interval
%  [-delay+interval(1),interval(2)]
%  4. interval is where the solution will be evaluated
%  5. N is the number of complex roots of W_r(a) with positive imaginary part
%  6. s is the stepsize of the solution
%-----------------------------------OUTPUT---------------------------------
%  sol is a struct containing the following fields:
%  1. sol.histx = mesh on [-delay+interval(1),interval(2)]
%  2. sol.histy = preshape function value at each sol.histx(i)
%  3. sol.x = mesh on the interval
%  4. sol.y = vector containing the solution to the NDDE at sol.x(i)
%  5. sol.c = vector containing coefficients C(i) in the solution
%  6. sol.l = vector containing lambda(i) in the solution
%  7. sol.psi = matrix with elements exp(lambda(i)*sol.histy(j))
%  8. sol.cond = condition number of matrix psi
%--------------------------------------------------------------------------

if isempty(N) && isempty(s)
    fprintf('Specify N=Number of complex roots of W_r(a) with positive complex part or s=stepsize')
    return
elseif isempty(N) && ~isempty(s)
    N=(floor((interval(2)-interval(1))/s)-1)/2;
elseif ~isempty(N) && isempty(s)
    s=(interval(2)-interval(1))/(2*N);
end


[a,r]=RA_solver(dydt,delay);

if dydt(2)==0 && dydt(3)==0
    % NDDE becomes y'=a_1 y, with solution y(t)=C*exp(a_1*t)
    tminus1=linspace(interval(1)-delay,interval(1),2*N+1);
    tspan=interval(1):s:interval(2);
    COEFF=preshape(interval(1))/exp(dydt(1)*interval(1));
    soln=@(t) COEFF*exp(dydt(1)*t);
    Y=soln(tspan);
    sol.y=Y;
    sol.cond=dydt(1);
    sol.histy=preshape(tminus1);
    sol.c=COEFF;
    sol.PSI=[];
    sol.x=tspan;
    sol.l=dydt(1);
elseif r==-1 && a==0
    % NDDE becomes y'=y'(t-h), with solution y(t)=C*t+b
    tminus1=linspace(interval(1)-delay,interval(1),2*N+1);
    tspan=interval(1):s:interval(2);
    ya=preshape(interval(1));
    yb=preshape(interval(1)-delay);
    C=(yb-ya)/(-delay);
    b=ya-(C*interval(1));
    soln=@(t) C*t+b;
    Y=soln(tspan);
    sol.x=tspan;
    sol.y=Y;
    sol.cond=C;
    sol.histy=preshape(tminus1);
    sol.c=C;
    sol.PSI=[];
    sol.l=0;
else
    % non negative branches
    q=0:N;
    % solving for zeta (~eigenvalues)
    zeta=lambda(dydt,delay,q);
    m=size(zeta,1);

    tspan=interval(1):s:interval(2);
    n=length(tspan);
    tminus1=linspace(interval(1)-delay,interval(1),m);
    yminus1=zeros(m,1);
    PSI_0=zeros(m,m);
    PSI_1=zeros(n,m);


    % preshape function
    for k=1:m
        yminus1(k)=preshape(tminus1(k));
    end

    for l=1:m
        for k=1:m
            PSI_0(l,k)=exp(zeta(k)*tminus1(l));
        end
    end
    sol.cond=cond(PSI_0);
    sol.psi=PSI_0;
    COEFF=PSI_0\yminus1;

    yminus2=PSI_0*COEFF;
    sol.histy=yminus2;
    sol.c=COEFF;

    for l=1:n
        for k=1:m
            PSI_1(l,k)=exp(zeta(k)*tspan(l));
        end
    end
    Y=PSI_1*COEFF;
    sol.x=tspan;
    sol.y=Y;
    sol.l=zeta;
    sol.histx=tminus1;
end
end



