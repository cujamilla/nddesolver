
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Example 1

% Solves the NDDE 
% y'(t)=y(t)+y(t-1)-0.25y'(t-1), on t=[0,2]
% with history function -t
% using the analytical solution, nddesolver, and ddensd and graphs the
% solution

step=0.1;
t=0:step:2;
interval=[0 2];
delay=1;

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% ANALYTICAL SOLUTION

y0=zeros(1,length(t));

for k=1:length(t)
    if t(k)<=1
        y0(k)=0.25*exp(t(k))+t(k)-0.25;
    else
        y0(k)=0.5-t(k)+0.25*exp(t(k))+(17/16)*exp(t(k)-1)+(3/16)*exp(t(k)-1)*t(k);
    end
end


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NDDE SOLVER

dydt=[1   1    -0.25];
N=10;
preshape=@(t) -t;
soln=nddesolver(dydt,delay,preshape,interval,N,[]);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % DDENSD SOLVER
% 
% sol = ddensd(@ddex1de,delay,delay,@ddehist,interval);
% y1=deval(t,sol);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Graphing

figure
plot(t,y0,'k','LineWidth',1.5);
hold
% plot(t,y1,'b--','LineWidth',1.5)
plot(soln.x,soln.y,'r*','LineWidth',1.5)
legend('Y_T','Y_D','Location','NorthWest')
% legend('Y_T','Y_D','Y_N','Location','NorthWest')
title('Example 1')


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Error computation
% % make sure that the vectors to compare are of the same size
% err=zeros(length(t),1);
% err1=zeros(length(t),1);
% for k=1:length(t)
%     err(k)=abs(soln.y(k)-y0(k));
%     err1(k)=abs(y1(k)-y0(k));
% end
% 
% E=norm(soln.y-y0')^2/norm(y0')^2;
% E1=norm(y1-y0)^2/norm(y0)^2;
% 
% % Error plot
% figure
% plot(t,err,'LineWidth',1.5)
% hold
% plot(t,err1,'LineWidth',1.5)
% title('Example 1')


%--------------------------------------------------------------------------
function dydt = ddex1de(~,y,Z,ZP)
dydt=y+Z-0.25*ZP;
end
%-------------------------------------------------------------------------
function s=ddehist(t)
s=-t;
end
%-------------------------------------------------------------------------
