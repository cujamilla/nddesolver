function w=rlambertw(k,x,r)
%-------------------------------ABOUT THE FUNCTION------------------------
% Computes the values of r-Lambert W function
%
% Note that the number of solutions of this function depend on the number
% of real roots of the r-Lambert W function W_r(a)
%-----------------------------------INPUT----------------------------------
%  1. k is the number of positive branches of r-Lambert W function
%  2. x and r are any real values
%-----------------------------------OUTPUT---------------------------------
%  1. w is the solution to the equation we^w + rw = x.
%--------------------------------------------------------------------------
narginchk(1,3);
if nargin == 1
    x = k;
    k = 0;
    r = 0;
end

if nargin == 2
    r = x;
    x = k;
    k = 0;
end


if ~isscalar(k) && ~isscalar(x) && ~isscalar(r) && ~isequal(size(x),size(k),size(r))
    error(message('symbolic:sym:ScalarOrSameSize'));
end

if ~isnumeric(k) || ~isnumeric(x) || ~isnumeric(r)
    error(message('symbolic:symbolic:NonNumericParameter'));
end

if any(~((isfinite(k) & k == fix(k)) | isnan(k)))
    error(message('symbolic:sym:lambertw:ExpectingInteger1'));
end

if isempty(k)
    w = k;
    return;
end
if isempty(x)
    w = x;
    return;
end
if isempty(r) % recheck this
    w = r;
    return;
end

if r==0
% when r==0, we have f(x)=xe^x-a.
% Note that lim f as x goes to -infinity=-a.
% Moreover, f'=(x+1)e^x so CN of f is -1.

f=@(w) w*exp(w)+r*w-x;
    if f(-1)<0 && -x>0
        w=size(length(k),1);
        % two real root
        for j=0:k(length(k))
        if j==0
            w(j+1)=lambertw(x);
        elseif j==1
            w(j+1)=lambertw(-1,x);
        else
            w(j+1)=lambertw(j-1,x);
        end
        end
    else
        % one real root, no real root
         w=lambertw(k,x);
        return
    end
elseif x==0
        startw=log(-r);
        if startw==0
            w=startw;
            return
        else
            if imag(startw)<0
                while imag(startw)<0
                    startw=startw+2i*pi;
                end
                w=startw.*ones(1,length(k))+(2i*pi.*(k(1):k(length(k))));
                w=[0 w(1:length(k)-1)];
                return
            elseif imag(startw)==0
                w=startw.*ones(1,length(k))+(2i*pi.*(k(1):k(length(k))));
                w=[0 w(1:length(k))];
                return
            else
                w=startw.*ones(1,length(k))+(2i*pi.*(k(1):k(length(k))));
                w=[0 w(1:length(k)-1)];
                return
            end
        end
elseif r>0 && r<exp(-2)
    if isscalar(k)
        w0 = getStartingPoint(k,r);
    else
        scale = ones(size(k)).*ones(size(x));
        k = scale .* k;
        x = scale .* x;
        r = scale .* r;
        w0 = arrayfun(@getStartingPoint,k,r,x);
    end

    % Halley's method
    w=Halley(w0,r,x);
else
        if isscalar(k)
            w0 = getStartingPoint(k,r);
        else
            scale = ones(size(k)).*ones(size(x));
            k = scale .* k;
            x = scale .* x;
            r = scale .* r;
            w0 = arrayfun(@getStartingPoint,k,r,x);
        end

        w = w0;

        % Halley's method
        w=Halley(w,r,x);
end
% add another term if more than one real root
    if imag(w(2))==0
        m=w(length(w))+2i*pi;
    m1=Halley(m,r,x);
    w=[w m1(1)];
    return
    end
end


% starting point per r
function w = getStartingPoint(k,r,x)
if r>0 && r<exp(-2)
    w = getStartingPointBranchpositiver1(k,r,x);
elseif r==exp(-2)
    w = getStartingPointBranchpositiver2(k,r,x);
elseif r>exp(-2)
    w = getStartingPointBranchpositiver3(k,r,x);
elseif r<0
    w = getStartingPointBranchnegative(k,r,x);
end
end


function w = getStartingPointBranchpositiver1(k,r,x)
% with additional branch 0+ and pm 1
% three possible real roots
f=@(w) w*exp(w)+r*w-x;
CN=lambertw(-1:0,-r*exp(1))-1;
CN1=round(CN,5);
if imag(CN1(1))==0 || imag(CN1(2))==0
    if f(CN1(2))>0 && f(CN1(1))<0
        if k==0
            w = 0;
        elseif k==1
            w = -2;
        elseif k==2
            w = -10;
        else
            w=imag(lambertw(k+1,-r*exp(1))-1)*1i-2i;
        end
    elseif f(CN1(2))<0 && f(CN1(1))>0
        if k==0
            w = 0;
        elseif k==1
            w = -2;
        elseif k==2
            w = -10;
        else
            w=imag(lambertw(k-1,-r*exp(1))-1)*1i-4i;
        end
    elseif f(CN1(2))<0 && f(CN1(1))<0
        if k==0
            w = 0;
        elseif k==1
            w=3i;
        else
            w = imag(lambertw(k,-r*exp(1))-1)*1i-3i;
        end
    else
        if k==0
            w = -10;
        elseif k==1
            w = 2i;
        else
            w = imag(lambertw(k,-r*exp(1))-1)*1i-4i;
        end
    end
end
end

function w = getStartingPointBranchpositiver2(k,r,~)
if k==1
    w = 3i;
elseif k==-1
    w = -3i;
elseif k==0
    w = -3; % principal branch 0- extends to minus infinity
elseif k==2
    w = imag(lambertw(k,-r*exp(1)-1))*1i-2i;
elseif k==-2
    w = imag(lambertw(k,-r*exp(1)-1))*1i+2i;
elseif k<0
    w = imag(lambertw(k,-r*exp(1))-1)*1i;
else
    w = -imag(lambertw(-k,-r*exp(1))-1)*1i;
end
end

function w = getStartingPointBranchpositiver3(k,r,x)
if k==0
    if x>0
    w = 3;
    else
    w = x/r;
    end
% elseif k==1
%     w=2i;
else
    w = imag(lambertw(k,-r*exp(1))-1)*1i-4i;
end
end


function w = getStartingPointBranchnegative(k,r,x)
% compute the minimum value of xe^x+rx-a
% if min>0, then no real zeros
% if min<0, 2 possible zeros
% if min=0, 1 zero
    minimumx=lambertw(-r*exp(1))-1;
    f=@(w) w*exp(w)+r*w-x;
    fvalue=f(minimumx);
    if fvalue>0
        if k==0
            w=1i;
        else
            w = imag(lambertw(k,-r*exp(1))-1)*1i+3i;
        end
    else
        if x>0
         % with branches 0- and 0+
            if k==0
                w = (x/r)*10; % we consider the branch 0-
            elseif k==1
                w = 2; % we consider the branch 0+
            else
                w = imag(lambertw(k,-r*exp(1))-1)*1i-4i;
            end
        elseif minimumx<0 && x<0
            % with branches 0- and 0+
            if k==0
                if abs(r-x)<1
                    w = r-x;
                else
                 w = -x/r;% we consider the branch 0-
                end
            elseif k==1
                w = minimumx-abs(minimumx+x/r); % we consider the branch 0+
            else
                w = imag(lambertw(k,-r*exp(1))-1)*1i-4i;
            end
        elseif minimumx>0 && x<0
            % with branches 0- and 0+
            if k==0
                w = x/r; % we consider the branch 0-
            elseif k==1
                w = minimumx+1; % we consider the branch 0+
            else
                w = imag(lambertw(k,-r*exp(1))-1)*1i-4i;
            end
        else
            if k==0
                w = minimumx-1; % we consider the branch 0-
            elseif k==1
                w = minimumx+1; % we consider the branch 0+
            else
                w = imag(lambertw(k,-r*exp(1))-1)*1i-4i;
            end
        end
    end
end


function w=Halley(w,r,x)
refine = true(size(w));
target = 1e-7;
if isa(x,'double')
    target = 1e-14;
end
loopCnt = 0;
while any(refine(:)) && (loopCnt < 25)
    e = exp(w);
    f = w.*e + r.*w - x;% Iterate to make this quantity zero
    df = (1+w).*e + r;
    ddf = (2+w).*e;
    w = w - ((2.*f.*df)./((2.*((df).^2))-(f.*ddf)));
    refine = abs(f)./abs(x) > target;
    loopCnt = loopCnt + 1;
end
end
