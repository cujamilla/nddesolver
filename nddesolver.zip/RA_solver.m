function [a,r]=RA_solver(dydt,delay)

%-------------------------------ABOUT THE FUNCTION------------------------------
%  THIS FUNCTION GIVES THE VALUES R,A IN THE rLambertW function.
% -----------------------------------INPUT--------------------------------------
%  1. dydt is a vector containing the coefficients of X,Z,and ZP
%	where  X is a function of t
%       Z is the function of t with constant delay
%       ZP is the derivative function of t with constant delay,
%     from the given equation to be solved, 
%     i.e. given FUN=(a1)X+(a2)Z+(a3)ZP, then dydt=[a1 a2 a3]
%  2. DELAY is the constant delay in the NDDE
%-----------------------------------OUTPUT--------------------------------------
%  1. a is the constant value in the rLambert equation x^exp(x)+r*x=a
%  2. r is the constant coefficient of x in the rLambert equation x^exp(x)+r*x=a
%-------------------------------------------------------------------------------

x0=exp(-delay*dydt(1));
r=double(-vpa(dydt(3)*x0));
a=double(vpa(delay*x0*(dydt(2)+(dydt(3)*dydt(1)))));